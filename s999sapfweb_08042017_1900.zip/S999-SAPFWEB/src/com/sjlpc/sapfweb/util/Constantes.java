package com.sjlpc.sapfweb.util;

public class Constantes {

	public static final String UNIDADE_PERSISTENCIA = "sapfweb";
}
