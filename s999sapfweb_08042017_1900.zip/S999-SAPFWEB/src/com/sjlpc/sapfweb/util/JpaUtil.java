/**
 * 
 */
package com.sjlpc.sapfweb.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * @author Savio Rodrigues
 *
 */
public class JpaUtil {

	static EntityManagerFactory emf;

	static {
		emf = Persistence.createEntityManagerFactory(Constantes.UNIDADE_PERSISTENCIA);
	}

	public static EntityManager geEntityManager() {
		return emf.createEntityManager();
	}

	public static void close() {
		if (emf.isOpen()) {
			emf.close();
		}
		if (geEntityManager().isOpen()) {
			geEntityManager().close();
		}

	}
	
	


}
