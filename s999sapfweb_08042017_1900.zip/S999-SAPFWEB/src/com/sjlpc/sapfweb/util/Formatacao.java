/**
 * 
 */
package com.sjlpc.sapfweb.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author Savio Rodrigues
 *
 */
public class Formatacao {

	public static Date getDataAtual() {
		Calendar calendar = new GregorianCalendar();
		Date date = new Date();
		calendar.setTime(date);
		return calendar.getTime();
	}
}
