/**
 * 
 */
package br.com.sjlpc.enums;

/**
 * @author Savio Rodrigues
 *
 */
public enum Status {

	ATIVO("A"), INVATIVO("I");

	private String descricao;

	private Status(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

}
