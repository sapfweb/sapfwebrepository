/**
 * 
 */
package br.com.sjlpc.sapfweb.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.sjlpc.sapfweb.util.JpaUtil;

import br.com.sjlpc.entidades.Usuario;

/**
 * @author Savio Rodrigues
 *
 */
public class UsuarioDAO {

	private EntityManager em;
	private EntityTransaction emt;

	protected UsuarioDAO(EntityManager em, EntityTransaction emt) {
		this.em = em;
		this.emt = emt;
	}

	public void adiciona(Usuario usuarios) throws SQLException {

		try {
			emt.begin();
			em.persist(usuarios);
			emt.commit();

		} catch (Exception e) {
			emt.rollback();
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public void atualiza(Usuario usuarios) throws SQLException {

		try {
			emt.begin();
			em.merge(usuarios);
			emt.commit();

		} catch (Exception e) {
			emt.rollback();
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public void remove(Usuario usuarios) throws SQLException {

		try {
			emt.begin();
			em.remove(usuarios);
			emt.commit();

		} catch (Exception e) {
			emt.rollback();
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public Usuario busca(Usuario usuario) throws SQLException {

		try {

			return em.find(Usuario.class, usuario.getCodigo());

		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public Usuario buscaPor(String login, String senha) {
		try {

			Usuario usuario = new Usuario();

			String sql = new StringBuilder().append(" select distinct u ").append(" from Usuario ")
					.append(" where u.login= :login ").append(" and senha= :senha ").toString();

			usuario = (Usuario) em.createQuery(sql).setParameter("login", login).setParameter("senha", senha)
					.getSingleResult();

			return usuario;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new PersistenceException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	@SuppressWarnings("unchecked")
	public List<Usuario> listarTodosUsuarios() throws SQLException {

		try {
			List<Usuario> listaUsuarios = new ArrayList<Usuario>();
			emt.begin();
			Query sql = em.createQuery("Select distinct c from Usuario;");
			listaUsuarios = (ArrayList<Usuario>) sql.getResultList();
			emt.commit();
			return listaUsuarios;

		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	@SuppressWarnings("unchecked")
	public List<Usuario> listarUsuariosPorNome(String nome) throws SQLException {

		try {

			List<Usuario> listaUsuarios = new ArrayList<Usuario>();
			String sql = new StringBuilder().append(" select distinct u  ").append(" from Usuario u ")
					.append(" where u.nome = :nome ").toString();

			listaUsuarios = (List<Usuario>) em.createQuery(sql).setParameter("nome", nome).getResultList();

			return listaUsuarios;
		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

}
