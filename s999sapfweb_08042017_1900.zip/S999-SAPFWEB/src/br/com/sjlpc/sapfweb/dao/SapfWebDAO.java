/**
 * 
 */
package br.com.sjlpc.sapfweb.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.sjlpc.sapfweb.util.JpaUtil;

/**
 * @author Savio Rodrigues
 *
 */
public class SapfWebDAO {

	private static EntityManager em;
	private static EntityTransaction emt;

	public static UsuarioDAO usuarioDAO() {
		return new UsuarioDAO(getEntityManager(), getEntityTransaction());
	}

	public static GrupoDAO grupoDAO() {
		return new GrupoDAO(getEntityManager(), getEntityTransaction());
	}

	private static EntityManager getEntityManager() {
		try {
			em = JpaUtil.geEntityManager();
			return em;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new PersistenceException(e.getMessage());
		}
	}

	private static EntityTransaction getEntityTransaction() {
		try {
			emt = em.getTransaction();
			return emt;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new PersistenceException(e.getMessage());
		}
	}
}
