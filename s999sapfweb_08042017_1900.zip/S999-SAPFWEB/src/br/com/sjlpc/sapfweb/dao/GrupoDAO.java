/**
 * 
 */
package br.com.sjlpc.sapfweb.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.sjlpc.sapfweb.util.JpaUtil;

import br.com.sjlpc.entidades.Grupo;

/**
 * @author Savio Rodrigues
 *
 */
public class GrupoDAO {

	private EntityManager em;
	private EntityTransaction emt;

	protected GrupoDAO(EntityManager em, EntityTransaction emt) {
		this.em = em;
		this.emt = emt;
	}

	public void adiciona(Grupo grupo) throws SQLException {

		try {
			emt.begin();
			em.persist(grupo);
			emt.commit();

		} catch (Exception e) {
			emt.rollback();
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public void atualiza(Grupo grupo) throws SQLException {

		try {
			emt.begin();
			em.merge(grupo);
			emt.commit();

		} catch (Exception e) {
			emt.rollback();
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public void remove(Grupo grupo) throws SQLException {

		try {
			emt.begin();
			em.remove(grupo);
			emt.commit();

		} catch (Exception e) {
			emt.rollback();
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

	public Grupo busca(Grupo grupo) throws SQLException {

		try {

			return em.find(Grupo.class, grupo.getCodigo());

		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}
	
	
	@SuppressWarnings("unchecked")
	public List<Grupo> listarTodosOsGrupos() throws SQLException {

		try {
			List<Grupo> listaGrupos = new ArrayList<Grupo>();
			em.getTransaction().begin();
			Query sql = em.createQuery("Select distinct g from Grupo ;");
			listaGrupos = (ArrayList<Grupo>) sql.getResultList();
			em.getTransaction().commit();
			return listaGrupos;

		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e.getMessage());
		} finally {
			JpaUtil.close();
		}

	}

}
