package br.com.sjlpc.sapfweb.dao;

import java.sql.SQLException;

import com.sjlpc.sapfweb.util.Formatacao;

import br.com.sjlpc.entidades.Grupo;
import br.com.sjlpc.entidades.Usuario;
import br.com.sjlpc.enums.Status;

public class Test {

	public static void main(String[] args) throws SQLException {

		GrupoDAO grupoDAO = SapfWebDAO.grupoDAO();

		Grupo grupo = new Grupo();
		Usuario usuario = new Usuario();

		usuario.setDataAtualizacao(Formatacao.getDataAtual());
		usuario.setLogin("saviojrc.1988@gmail.com");
		usuario.setSenha("s2468101");
		usuario.setStatus(Status.ATIVO);
		usuario.setNome("Administrador");

		grupo.setDataAtualizacao(Formatacao.getDataAtual());
		grupo.setNome("Administradores");
		grupo.setStatus(Status.ATIVO);

		// grupoDAO.adiciona(grupo);
		grupo.setCodigo(01);

	}

}
